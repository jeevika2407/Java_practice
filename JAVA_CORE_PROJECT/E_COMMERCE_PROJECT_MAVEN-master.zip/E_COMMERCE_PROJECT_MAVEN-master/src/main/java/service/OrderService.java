package service;
import java.util.List;

import dao.OrderDAO;
import model.Order;

public class OrderService {
    private OrderDAO orderDAO;

    public OrderService(OrderDAO orderDAO) {
        this.orderDAO = orderDAO;
    }

    
    public void placeOrder(Order order) {
        orderDAO.addOrder(order);
    }


    public Order getOrderById(int orderId) {
        return orderDAO.getOrderById(orderId);
    }

    
    public List<Order> getCustomerOrders(int customerId) {
        return orderDAO.getOrdersByCustomer(customerId);
    }

   
    public List<Order> getOrdersBySeller(int sellerId) {
        return orderDAO.getOrdersBySeller(sellerId);
    }

 
    public void updateOrderStatus(int orderId, String status) {
        orderDAO.updateOrderStatus(orderId, status);
    }


	public List<Order> getAllOrders() {
		// TODO Auto-generated method stub
		return orderDAO.getAllOrders();
	}
}