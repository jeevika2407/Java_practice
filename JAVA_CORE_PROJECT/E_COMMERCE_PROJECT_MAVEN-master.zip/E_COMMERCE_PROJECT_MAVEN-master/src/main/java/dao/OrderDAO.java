package dao;
import java.util.List;

import model.Order;

public interface OrderDAO {
    void addOrder(Order order);
    Order getOrderById(int orderId);
    List<Order> getOrdersByCustomer(int customerId);
    List<Order> getOrdersBySeller(int sellerId);
    void updateOrderStatus(int orderId, String status);
	List<Order> getAllOrders();
}