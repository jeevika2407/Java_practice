package oops.test;
import java.util.*;

class Customer {
    private int id;
    private String name;
    private char gender;

    public Customer(int id, String name, char gender) {
        super();
        this.id = id;
        this.name = name;
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String toString() {
        return "Customer [id=" + id + "]";
    }
}

class Account {
    Customer c;
    private int Id;
    private double balance;

    public Account(Customer c, int Id, double balance) {
        super();
        this.c = c;
        this.Id = Id;
        this.balance = balance;
    }

    public Customer getC() {
        return c;
    }

    public void setC(Customer c) {
        this.c = c;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String toString() {
        return "Account [Id=" + Id + ", balance=" + balance + "]";
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("After deposit: " + balance);
    }

    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Balance is: " + balance);
        } else {
            System.out.println("Amount withdrawn exceeds the current balance!");
        }
    }
}

public class Ques1 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        Customer customer = new Customer(1, "jeev", 'F');
        Account a = new Account(customer, 1001, 10000.0);

        System.out.println("PLEASE SELECT ONE OPTION FROM BELOW\n1. WITHDRAW\n2. DEPOSIT\n3. CHECK BALANCE\n4. EXIT ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                System.out.println("OPTION: 1");
                System.out.println("ENTER AMOUNT TO WITHDRAW:");
                a.withdraw(sc.nextDouble());
                break;

            case 2:
                System.out.println("OPTION: 2");
                System.out.println("ENTER AMOUNT TO DEPOSIT:");
                a.deposit(sc.nextDouble());
                break;

            case 3:
                System.out.println("OPTION: 3");
                System.out.println("CHECK BALANCE: " + a.getBalance());
                break;

            case 4:
                System.out.println("EXIT");
                break;

            default:
                System.out.println("INVALID OPTION");
        }
        sc.close();
    }
}
