package JAva;
import java.util.*;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Total number of passengers: ");
        int totalPass = sc.nextInt();
        
        int totalFare = 0;
    
        for (int i = 0; i < totalPass; i++) {
//            sc.nextLine(); 
	            System.out.println("Enter details for passenger "+(i+1)+ ":");
	            System.out.println("Name: ");
	            String name = sc.next();
	            System.out.println("Age: ");
	            int age = sc.nextInt();
	            sc.nextLine(); 
	            System.out.println("Boarding Point (Pune/Lonavala): ");
	            String boardingPoint = sc.next();
            
            int fare = 0;
            if (age < 5) {
                fare = 0; 
                if (boardingPoint.equals("Pune")) {
                    fare = 295;
                } else if (boardingPoint.equals("Lonavala")) {
                    fare = 235;
                }
            }
            totalFare += fare;
        }
    
        System.out.println("Total fare amount is" + totalFare); 
        sc.close();
    }
}
