package JAva;
import java.util.*;
public class Q2 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		int y=sc.nextInt();
		int add=0;
		int add1=0;
		for(int i=1;i<=x;i++) {
			if(x%i==0) {
				add += i;
			}
		}
		for(int i=1;i<=y;i++) {
			if(y%i==0) {
				add1 += i;
			}
		}
		if(add==add1) {
			System.out.println("true");
		}
		else {
			System.out.println("false");
		}
		sc.close();
	}
}
