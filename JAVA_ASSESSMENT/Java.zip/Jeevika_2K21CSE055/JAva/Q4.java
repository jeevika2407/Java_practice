import java.util.Scanner;

public class Q4{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int max = -1;
        
        while (true) {
            int price = sc.nextInt();
            if (price == -1) { 
                break;
            }
            if (price > max) { 
                max = price;
            }
        }
        
        if (max==-1) {
            return;
        } else {
            System.out.println(max);
        }
        
        sc.close();
    }
}
