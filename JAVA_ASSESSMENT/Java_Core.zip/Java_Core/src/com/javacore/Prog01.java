package com.javacore;
import java.util.*;

public class Prog01 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter string:");
        String str = sc.nextLine();
        char[] ch = str.toCharArray();
        int n = ch.length;
        boolean found = false;

        for (int i = 0; i < n; i++) {
            char cur = ch[i];
            int count = 1;
            
            for (int j = i + 1; j < n; j++) {
                if (ch[j] == cur) {
                    found = true;
                    count++;
                    ch[j] = '#'; 
                }
            }
           
            if (found) {
                System.out.println(cur + ": " + count);
            }
        }

        if (!found) {
            System.out.println("no duplicates");
        }
    }
}
